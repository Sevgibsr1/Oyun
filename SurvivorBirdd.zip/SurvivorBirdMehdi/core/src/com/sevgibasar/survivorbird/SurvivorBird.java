package com.sevgibasar.survivorbird;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.math.Circle;
import com.badlogic.gdx.math.Intersector;
import com.badlogic.gdx.utils.ScreenUtils;
import java.util.Random;
import javax.management.StringValueExp;

public class SurvivorBird extends ApplicationAdapter {

	SpriteBatch batch;
	Texture background;
	Texture[] birdTextures ;
	Texture[] beeTextures;
	int birdFrame = 0;
	int beeFrame = 0;
	float stateTime = 0f;
	float frameDuration = 0.1f;
	float birdX;
	float birdY;
	int gameState = 0;
	float velocity = 0;
	float gravity = 0.5f;
	int score = 0;
	int scoredEnemy;
	BitmapFont font;
	BitmapFont font2;

	int numberOfEnemies = 4;
	float [] beeX = new float[numberOfEnemies];
	float [] beeOffset = new float[numberOfEnemies];
	float [] beeOffset2 = new float[numberOfEnemies];
	float [] beeOffset3 = new float[numberOfEnemies];

	float distance = 0;
	float beeVelocity = 20;
	Random random;

	Circle birdCircle;
	Circle [] enemyCircles;
	Circle [] enemyCircles2;
	Circle [] enemyCircles3;

	ShapeRenderer shapeRenderer;

	@Override
	public void create () {
		batch = new SpriteBatch();
		background = new Texture("Full-Background.png");
		birdTextures = new Texture[7];
		beeTextures = new Texture[6];
		for (int i = 0; i < 7; i++) {
			birdTextures[i] = new Texture("bird-" + (i + 1) + ".png");
			if (i ==6){
				continue;
			}
			beeTextures[i] = new Texture("bee-" + (i + 1) + ".png");
		}

		distance = Gdx.graphics.getWidth()/2;

		random = new Random();

		birdX = Gdx.graphics.getWidth() / 5;
		birdY = Gdx.graphics.getHeight() / 2;

		shapeRenderer = new ShapeRenderer();

		birdCircle = new Circle();
		enemyCircles = new Circle[numberOfEnemies];
		enemyCircles2 = new Circle[numberOfEnemies];
		enemyCircles3 = new Circle[numberOfEnemies];

		font = new BitmapFont();
		font.setColor(Color.WHITE);
		font.getData().setScale(4);

		font2 = new BitmapFont();
		font2.setColor(Color.WHITE);
		font2.getData().setScale(6);

		for(int i = 0; i < numberOfEnemies; i++){

			beeOffset[i] = (random.nextFloat() - 0.5f) * Gdx.graphics.getHeight();
			beeOffset2[i] = (random.nextFloat() - 0.5f) * Gdx.graphics.getHeight();
			beeOffset3[i] = (random.nextFloat() - 0.5f) * Gdx.graphics.getHeight();

			beeX[i] = Gdx.graphics.getWidth() - beeTextures[i].getWidth()/2 + i * distance;

			enemyCircles[i] = new Circle();
			enemyCircles2[i] = new Circle();
			enemyCircles3[i] = new Circle();
		}


	}

	@Override
	public void render () {
		batch.begin();
		batch.draw(background,0,0, Gdx.graphics.getWidth(),Gdx.graphics.getHeight());

		if(gameState == 1) {

			if(beeX[scoredEnemy] < Gdx.graphics.getWidth() / 5){
				score++;
				if (scoredEnemy < numberOfEnemies - 1){
					scoredEnemy++;
				}else {
					scoredEnemy = 0;
				}
			}

			if(Gdx.input.justTouched()) {
				velocity = -10;
			}

			stateTime += Gdx.graphics.getDeltaTime();
			if (stateTime > frameDuration) {
				birdFrame = (birdFrame + 1) % birdTextures.length;
				beeFrame = (beeFrame + 1) % beeTextures.length;
				stateTime = 0f;
			}


			for (int i = 0; i < numberOfEnemies; i++){
				if (beeX[i] < -beeTextures[i].getWidth()){
					beeX[i] = beeX[i] + numberOfEnemies * distance;

					beeOffset[i] = (random.nextFloat() - 0.5f) * Gdx.graphics.getHeight() ;
					beeOffset2[i] = (random.nextFloat() - 0.5f) * Gdx.graphics.getHeight() ;
					beeOffset3[i] = (random.nextFloat() - 0.5f) * Gdx.graphics.getHeight() ;

				}else {
					beeX[i] = beeX[i] - beeVelocity;
				}

				batch.draw(beeTextures[beeFrame],beeX[i],Gdx.graphics.getHeight()/2 + beeOffset[i],Gdx.graphics.getWidth() / 15, Gdx.graphics.getHeight() / 10);
				batch.draw(beeTextures[beeFrame],beeX[i],Gdx.graphics.getHeight()/2 + beeOffset2[i],Gdx.graphics.getWidth() / 15, Gdx.graphics.getHeight() / 10);
				batch.draw(beeTextures[beeFrame],beeX[i],Gdx.graphics.getHeight()/2 + beeOffset3[i],Gdx.graphics.getWidth() / 15, Gdx.graphics.getHeight() / 10);

				enemyCircles[i] = new Circle(beeX[i] + Gdx.graphics.getWidth() / 30, Gdx.graphics.getHeight()/2 + beeOffset[i] + Gdx.graphics.getHeight() / 20,Gdx.graphics.getWidth() / 30);
				enemyCircles2[i] = new Circle(beeX[i] + Gdx.graphics.getWidth() / 30, Gdx.graphics.getHeight()/2 + beeOffset2[i] + Gdx.graphics.getHeight() / 20,Gdx.graphics.getWidth() / 30);
				enemyCircles3[i] = new Circle(beeX[i] + Gdx.graphics.getWidth() / 30, Gdx.graphics.getHeight()/2 + beeOffset3[i] + Gdx.graphics.getHeight() / 20,Gdx.graphics.getWidth() / 30);

			}

			if (birdY > 0){
				velocity +=gravity;
				birdY = birdY - velocity;
			}else {
				gameState = 2;
			}
		}else if(gameState == 0){
			if(Gdx.input.justTouched()) {
				gameState = 1;
			}
		}else if (gameState == 2){
			font2.draw(batch,"Game Over! Tap To Play Again!",100, Gdx.graphics.getHeight()/2);
			if(Gdx.input.justTouched()) {
				gameState = 1;
				birdY = Gdx.graphics.getHeight() / 2;

				for(int i = 0; i < numberOfEnemies; i++){

					beeOffset[i] = (random.nextFloat() - 0.5f) * Gdx.graphics.getHeight() - 200;
					beeOffset2[i] = (random.nextFloat() - 0.5f) * Gdx.graphics.getHeight() - 200;
					beeOffset3[i] = (random.nextFloat() - 0.5f) * Gdx.graphics.getHeight() - 200;

					beeX[i] = Gdx.graphics.getWidth() - beeTextures[i].getWidth()/2 + i * distance;

					enemyCircles[i] = new Circle();
					enemyCircles2[i] = new Circle();
					enemyCircles3[i] = new Circle();
				}

				velocity = 0;
				scoredEnemy = 0;
				score = 0;
			}

		}
		batch.draw(birdTextures[birdFrame], birdX, birdY,
				Gdx.graphics.getWidth() / 15, Gdx.graphics.getHeight() / 10);

		font.draw(batch, String.valueOf(score),100,200);




		batch.end();

		birdCircle.set(birdX + Gdx.graphics.getWidth() / 30,birdY + Gdx.graphics.getHeight() / 20,Gdx.graphics.getWidth() / 30);
		//shapeRenderer.begin(ShapeRenderer.ShapeType.Filled);
		//shapeRenderer.setColor(Color.BLACK);
		//shapeRenderer.circle(birdCircle.x,birdCircle.y,birdCircle.radius);


		for(int i = 0; i < numberOfEnemies; i++){
			//shapeRenderer.circle(beeX[i] + Gdx.graphics.getWidth() / 30, Gdx.graphics.getHeight()/2 + beeOffset[i] + Gdx.graphics.getHeight() / 20,Gdx.graphics.getWidth() / 30);
			//shapeRenderer.circle(beeX[i] + Gdx.graphics.getWidth() / 30, Gdx.graphics.getHeight()/2 + beeOffset2[i] + Gdx.graphics.getHeight() / 20,Gdx.graphics.getWidth() / 30);
			//shapeRenderer.circle(beeX[i] + Gdx.graphics.getWidth() / 30, Gdx.graphics.getHeight()/2 + beeOffset3[i] + Gdx.graphics.getHeight() / 20,Gdx.graphics.getWidth() / 30);

			if (Intersector.overlaps(birdCircle,enemyCircles[i]) || Intersector.overlaps(birdCircle,enemyCircles2[i]) || Intersector.overlaps(birdCircle,enemyCircles3[i])){
				gameState = 2;
			}
		}

		//shapeRenderer.end();
	}

	@Override
	public void dispose(){
		batch.dispose();
		background.dispose();

		for (Texture birdTexture : birdTextures) {
			birdTexture.dispose();
		}

		for (Texture beeTexture : beeTextures) {
			beeTexture.dispose();
		}

		font.dispose();
		font2.dispose();

		shapeRenderer.dispose(); // ShapeRenderer'ı da serbest bırakın
	}
}
